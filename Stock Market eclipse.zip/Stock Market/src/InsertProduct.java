
public class InsertProduct {

}
