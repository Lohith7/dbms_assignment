
public class DeleteCompany {

}
