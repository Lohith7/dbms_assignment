
public class DeleteProduct {

}
