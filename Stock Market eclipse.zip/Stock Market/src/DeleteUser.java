
public class DeleteUser {

}
