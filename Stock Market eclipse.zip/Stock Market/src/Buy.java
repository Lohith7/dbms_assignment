public class Buy {

}
