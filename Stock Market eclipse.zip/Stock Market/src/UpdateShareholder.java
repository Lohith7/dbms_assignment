import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateShareholder extends Panel 
{
	Button updateShareholderButton;
	List shIDList;
	TextField sidText, snameText,glText, svText,cidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateShareholder() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","it18737070","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSailors() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SID FROM shareholders");
		  while (rs.next()) 
		  {
			shIDList.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    shIDList = new List(10);
		loadSailors();
		add(shIDList);
		
		//When a list item is selected populate the text fields
		shIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM shareholders where SID ="+shIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("SID"));
					snameText.setText(rs.getString("SNAME"));
					glText.setText(rs.getString("GAIN_OR_LOSS"));
					svText.setText(rs.getString("SHAREVALUE"));
					cidText.setText(rs.getString("CID"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateShareholderButton = new Button("Update Sailor");
		updateShareholderButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE shareholders "
					+ "SET sname='" + snameText.getText() + "', "
					+ "GAIN_OR_LOSS='" + glText.getText() + "', "
					+ "SHAREVALUE ="+ svText.getText() + " WHERE sid = "
					+ shIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					shIDList.removeAll();
					loadSailors();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		snameText = new TextField(15);
		glText = new TextField(15);
		svText = new TextField(15);
		cidText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Shareholder ID:"));
		first.add(sidText);
		first.add(new Label("Shareholder Name:"));
		first.add(snameText);
		first.add(new Label("Gain/Loss:"));
		first.add(glText);
		first.add(new Label("Share Value:"));
		first.add(svText);
		first.add(new Label("CID:"));
		first.add(cidText);
		
		Panel second = new Panel(new GridLayout(6, 1));
		second.add(updateShareholderButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateShareholder ups = new UpdateShareholder();

	
		ups.buildGUI();
	}
}
