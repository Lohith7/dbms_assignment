import java.awt.*; 
import java.awt.event.*; 

class StockmarketGUI extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  InsertShareholder sail;
	  UpdateShareholder ups;
	  DeleteShareholder dels;
	  InsertUser insu;
	  Panel home,welcome; 
	  
	  StockmarketGUI() 
	  { 
			cardLO = new CardLayout(); 
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setText("Welcome to Stock Market Application");
			
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);		 
			
			//create panels for each of our menu items and build them with respective components
			sail = new InsertShareholder(); sail.buildGUI();
			ups = new UpdateShareholder();  ups.buildGUI();
			dels = new DeleteShareholder();	dels.buildGUI();
			insu = new InsertUser(); insu.buildGUI();

			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(sail, "InsertShareholder"); 
			home.add(ups, "UpdateShareholder"); 
			home.add(dels, "DeleteShareholder");
			home.add(insu, "InsertUser");
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu sh = new Menu("Shareholders"); 
			MenuItem item1, item2, item3; 
			sh.add(item1 = new MenuItem("Insert Shareholder")); 
			sh.add(item2 = new MenuItem("View Shareholders")); 
			sh.add(item3 = new MenuItem("Delete Shareholder")); 
			mbar.add(sh); 
		 
			Menu com = new Menu("Company"); 
			MenuItem item4, item5, item6; 
			com.add(item4 = new MenuItem("Insert Company")); 
			com.add(item5 = new MenuItem("View Companies")); 
			com.add(item6 = new MenuItem("Delete Company"));  
			mbar.add(com); 
			
			Menu reserve = new Menu("Users"); 
			MenuItem item7, item8, item9; 
			reserve.add(item7 = new MenuItem("Add User")); 
			reserve.add(item8 = new MenuItem("View Users")); 
			reserve.add(item9 = new MenuItem("Delete User")); 
			mbar.add(reserve);
			
			Menu pro = new Menu("Products"); 
			MenuItem item10, item11, item12; 
			pro.add(item10 = new MenuItem("Add Product")); 
			pro.add(item11 = new MenuItem("View Products")); 
			pro.add(item12 = new MenuItem("Delete Product")); 
			mbar.add(pro);
			
			Menu act = new Menu("Action"); 
			MenuItem item13, item14, item15; 
			act.add(item13 = new MenuItem("Buy")); 
			act.add(item14 = new MenuItem("Hold")); 
			act.add(item15 = new MenuItem("Have")); 
			mbar.add(act);
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this);
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Stockmarket"); 
			Color clr = new Color(0,191,255);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Shareholder"))
		  {
			cardLO.show(home, "InsertShareholder"); 			
          }			
		 
		 else if(arg.equals("View Shareholders")) 
		 {
			cardLO.show(home, "UpdateShareholder"); 			
		 }
		 
		 else if(arg.equals("Delete Shareholder")) 
		 {
			cardLO.show(home, "DeleteShareholder"); 			
		 }
		 else if(arg.equals("Insert User"))
		 {
			cardLO.show(home, "InsertUser"); 			
         }			
		 else if(arg.equals("View Users")) 
		 {
			cardLO.show(home, "UpdateUser"); 			
		 }
		 
		 else if(arg.equals("Delete User")) 
		 {
			cardLO.show(home, "DeleteUser"); 			
		 }
		 
		 else if(arg.equals("Insert Company")) 
		 {
			cardLO.show(home, "InsertCompany"); 				
		 }
		 else if(arg.equals("View Companies")) 
		 {
			cardLO.show(home, "UpdateCompany"); 				
		 }
		 else if(arg.equals("Delete Company"))
		 {
			cardLO.show(home, "DeleteCompany"); 				
		 }
		 else if(arg.equals("Insert Product")) 
		 {
			cardLO.show(home, "InsertProduct"); 				
		 }
		 else if(arg.equals("View Products")) 
		 {
			cardLO.show(home, "UpdateProduct"); 				
		 }
		 else if(arg.equals("Delete Product")) 
		 {
			cardLO.show(home, "DeleteProduct"); 				
		 }
		 else if(arg.equals("Buy")) 
		 {
			cardLO.show(home, "Buy"); 				
		 }
		 else if(arg.equals("Hold")) 
		 {
			cardLO.show(home, "Hold"); 				
		 }
		 else if(arg.equals("Have")) 
		 {
			cardLO.show(home, "Have");		
		 }
	  }
	  public static void main(String ... args)
	  {
			new StockmarketGUI();	  
	  }
} 
 

 
